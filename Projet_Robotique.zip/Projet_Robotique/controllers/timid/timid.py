from controller import Robot

robot = Robot()
timestep = int(robot.getBasicTimeStep())

# --- Moteurs ---
motor_left = robot.getDevice("motor.left")
motor_right = robot.getDevice("motor.right")
motor_left.setPosition(float('inf'))
motor_right.setPosition(float('inf'))
motor_left.setVelocity(0.0)
motor_right.setVelocity(0.0)

# --- Capteurs ---
distanceSensors = []
for i in range(7):
    s = robot.getDevice('prox.horizontal.' + str(i))
    s.enable(timestep)
    distanceSensors.append(s)

# --- Paramètres ---
TH_OBS = 600     # seuil obstacle
V_FWD = 3.0

while robot.step(timestep) != -1:

    vals = [distanceSensors[i].getValue() for i in range(7)]
    front = max(vals[0], vals[1], vals[2], vals[3], vals[4])

    # --- LOGIQUE TIMID ---
    if front > TH_OBS:
        v = 0.0      # STOP
    else:
        v = V_FWD    # AVANCE

    motor_left.setVelocity(v)
    motor_right.setVelocity(v)