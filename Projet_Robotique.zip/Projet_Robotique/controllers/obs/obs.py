from controller import Robot

robot = Robot()
timestep = int(robot.getBasicTimeStep())

# --- Moteurs ---
motor_left = robot.getDevice("motor.left")
motor_right = robot.getDevice("motor.right")
motor_left.setPosition(float('inf'))
motor_right.setPosition(float('inf'))
motor_left.setVelocity(0.0)
motor_right.setVelocity(0.0)

# --- Capteurs ---
distanceSensors = []
for i in range(7):
    s = robot.getDevice('prox.horizontal.' + str(i))
    s.enable(timestep)
    distanceSensors.append(s)

# --- Paramètres ---
TH_ON = 400      # seuil détection obstacle
TH_OFF = 250     # seuil libération (évite vibration)
V_FWD = 3.0
V_BACK = -6.0

mode = "FWD"

while robot.step(timestep) != -1:

    vals = [distanceSensors[i].getValue() for i in range(7)]
    front = max(vals[0], vals[1], vals[2], vals[3], vals[4])

    # --- LOGIQUE OBSTINÉ ---
    if mode == "FWD":
        if front > TH_ON:
            mode = "BACK"
    else:  # mode == BACK
        if front < TH_OFF:
            mode = "FWD"

    # --- ACTION ---
    if mode == "BACK":
        v = V_BACK
    else:
        v = V_FWD

    motor_left.setVelocity(v)
    motor_right.setVelocity(v)